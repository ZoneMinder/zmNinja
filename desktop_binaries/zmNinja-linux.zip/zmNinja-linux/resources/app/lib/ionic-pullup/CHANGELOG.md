# v1.0.2

## Breaking change
Removed ```minimize``` attribute from ```ion-pull-up-footer``` directive and added two new attributes for better behavior

- initial-state: "collapsed" || "minimized"
- default-behavior: "expand" || "hide"

# v1.0.1
fixed DI issue in ```ion-pull-up-footer``` controller

# v1.0.0
Initial release