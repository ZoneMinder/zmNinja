## v0.4.2

 * publish to npm

## v0.4.1

 * support for main button click other than open/close (27e68fb)
 * fix FF issue: svg icons not aligned for main button (1c1b672, [#21](https://github.com/nobitagit/ng-material-floating-button/issues/21))
 * start this changelog.

## v0.4.0

 * support for Angular Material
